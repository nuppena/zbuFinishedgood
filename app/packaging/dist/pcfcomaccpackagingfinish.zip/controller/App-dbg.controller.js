sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("pcf.com.acc.packaging.finishedgoods.controller.App", {
      onInit() {
      }
  });
});