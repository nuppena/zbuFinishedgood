sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("pcf.com.acc.packaging.finishedgoods.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map