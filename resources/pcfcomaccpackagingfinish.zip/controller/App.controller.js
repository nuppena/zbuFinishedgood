sap.ui.define(["sap/ui/core/mvc/Controller"],c=>{"use strict";return c.extend("pcf.com.acc.packaging.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map